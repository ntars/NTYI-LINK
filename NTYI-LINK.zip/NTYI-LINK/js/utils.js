// js/utils.js - 工具函数整合
// 包含：通用工具、首页功能、搜索页功能、知识管理器

/**
 * 返回首页
 */
function goHome() {
    if (typeof SPARouter !== 'undefined') {
        SPARouter.goHome();
    } else {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '0';
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 300);
    }
}

/**
 * 返回上一页（如果没有上一页则回到主页）
 */
function goBack() {
    if (typeof SPARouter !== 'undefined') {
        SPARouter.goBack();
    } else {
        const hasReferrer = document.referrer && 
                           document.referrer !== '' && 
                           document.referrer !== window.location.href;
        
        if (hasReferrer) {
            document.body.style.transition = 'opacity 0.3s ease';
            document.body.style.opacity = '0';
            setTimeout(() => {
                window.location.href = document.referrer;
            }, 300);
        } else {
            goHome();
        }
    }
}

/**
 * 禁用右键菜单
 */
function disableContextMenu() {
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        return false;
    });
}

/**
 * 禁用复制粘贴
 */
function disableCopyPaste() {
    document.addEventListener('copy', (e) => {
        e.preventDefault();
        return false;
    });
    
    document.addEventListener('cut', (e) => {
        e.preventDefault();
        return false;
    });
    
    document.addEventListener('paste', (e) => {
        e.preventDefault();
        return false;
    });
}

/**
 * 绑定主题切换按钮
 */
function bindThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            ThemeManager.toggleTheme();
        });
    }
}

// ==================== 首页功能模块 ====================
const IndexPageManager = {
    initialized: false,
    
    init() {
        // 初始化万年历模块
        if (typeof AlmanacModule !== 'undefined') {
            AlmanacModule.init();
        }
        this.initialized = true;
        console.log('首页万年历模块已加载');
    }
};

// ==================== 搜索页功能模块 ====================
const SearchPageManager = {
    internalSearchData: [],

    currentEngine: 'internal',

    searchEngines: {
        internal: { name: '站内', url: '' },
        baidu: { name: '百度', url: 'https://www.baidu.com/s?wd=' },
        google: { name: 'Google', url: 'https://www.google.com/search?q=' },
        bing: { name: 'Bing', url: 'https://www.bing.com/search?q=' }
    },

    async init() {
        await this.loadSearchData();
        this.initSearchEngineSelector();
        this.bindSearchEvents();
        this.addSearchAnimations();
    },

    async loadSearchData() {
        try {
            // 加载词条数据
            const termsResponse = await fetch('data/entry.json');
            const termsData = await termsResponse.json();
            const terms = (termsData.terms || []).map(term => ({
                type: '词条',
                title: term.title,
                description: term.description,
                content: term.content,
                url: `#knowledge`,
                id: term.id
            }));

            // 加载文章数据
            const articlesResponse = await fetch('data/articles.json');
            const articlesData = await articlesResponse.json();
            const articles = (articlesData.articles || []).map(article => ({
                type: '文章',
                title: article.title,
                description: article.description,
                content: article.content,
                url: `#knowledge`,
                id: article.id
            }));

            // 合并数据
            this.internalSearchData = [...terms, ...articles];
            console.log('搜索数据加载完成，共', this.internalSearchData.length, '条');
        } catch (error) {
            console.error('搜索数据加载失败:', error);
            // 使用默认数据
            this.internalSearchData = [
                { type: '词条', title: '农历', description: '中国传统历法，又称阴历、夏历，以月相变化周期为一个月。', url: '#knowledge' },
                { type: '文章', title: '二十四节气详解', description: '中国古代订立的一种用来指导农事的补充历法。', url: '#knowledge' }
            ];
        }
    },

    initSearchEngineSelector() {
        const options = document.querySelectorAll('.engine-option');
        
        options.forEach(option => {
            option.addEventListener('click', (e) => {
                e.preventDefault();
                const engine = option.dataset.engine;
                
                options.forEach(opt => {
                    opt.classList.remove('active');
                    const radio = opt.querySelector('input[type="radio"]');
                    if (radio) radio.checked = false;
                });
                
                option.classList.add('active');
                const currentRadio = option.querySelector('input[type="radio"]');
                if (currentRadio) currentRadio.checked = true;
                
                this.currentEngine = engine;
                this.updateSearchUI(engine);
            });
        });
    },

    bindSearchEvents() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch();
                }
            });
        }
        
        const searchButton = document.getElementById('searchButton');
        if (searchButton) {
            searchButton.addEventListener('click', () => {
                this.performSearch();
            });
        }
    },

    updateSearchUI(engine) {
        const searchInput = document.getElementById('searchInput');
        if (!searchInput) return;
        
        const logoWrappers = document.querySelectorAll('.engine-logo-wrapper');
        logoWrappers.forEach(wrapper => {
            wrapper.classList.remove('active');
        });
        
        const currentWrapper = document.querySelector(`.engine-logo-wrapper[data-engine="${engine}"]`);
        if (currentWrapper) {
            currentWrapper.classList.add('active');
        }
        
        if (engine === 'internal') {
            searchInput.placeholder = '搜索站内词条、文章...';
        } else {
            const engineName = this.searchEngines[engine].name;
            searchInput.placeholder = `在${engineName}中搜索...`;
        }
        
        const resultsContainer = document.getElementById('searchResults');
        if (resultsContainer) {
            resultsContainer.innerHTML = '<div class="no-results"><p>输入关键词开始搜索</p></div>';
        }
    },

    performSearch() {
        const keyword = document.getElementById('searchInput').value.trim();
        
        if (!keyword) {
            alert('请输入搜索关键词');
            return;
        }

        if (this.currentEngine === 'internal') {
            this.performInternalSearch(keyword);
        } else {
            const engine = this.searchEngines[this.currentEngine];
            const searchUrl = engine.url + encodeURIComponent(keyword);
            window.open(searchUrl, '_blank');
        }
    },

    performInternalSearch(keyword) {
        const resultsContainer = document.getElementById('searchResults');
        if (!resultsContainer) return;
        
        // 搜索标题、描述和内容
        const results = this.internalSearchData.filter(item => 
            item.title.includes(keyword) || 
            item.description.includes(keyword) ||
            (item.content && item.content.includes(keyword))
        );

        if (results.length === 0) {
            resultsContainer.innerHTML = '<div class="no-results"><p>未找到相关结果</p></div>';
        } else {
            let html = '';
            results.forEach((item, index) => {
                html += `
                    <div class="result-item" style="animation: fadeInUp 0.3s ease ${index * 0.1}s both;" onclick="KnowledgeManager.showDetailById('${item.id}', '${item.type}')">
                        <div class="result-title">
                            <span class="result-type">${item.type}</span>
                            ${item.title}
                        </div>
                        <div class="result-description">${item.description}</div>
                    </div>
                `;
            });
            resultsContainer.innerHTML = html;
        }
    }
};

// ==================== 知识管理器 ====================
const KnowledgeManager = {
    terms: [],
    articles: [],

    async init() {
        await this.loadData();
        this.renderTerms();
        this.renderArticles();
    },

    async loadData() {
        try {
            const termsResponse = await fetch('data/entry.json');
            const termsData = await termsResponse.json();
            this.terms = termsData.terms || [];

            const articlesResponse = await fetch('data/articles.json');
            const articlesData = await articlesResponse.json();
            this.articles = articlesData.articles || [];

            console.log('知识数据加载完成：词条', this.terms.length, '条，文章', this.articles.length, '篇');
        } catch (error) {
            console.error('知识数据加载失败:', error);
            this.loadDefaultData();
        }
    },

    loadDefaultData() {
        this.terms = [
            {
                id: 'lunar-calendar',
                title: '农历文化',
                icon: 'calendar',
                description: '农历是中国传统历法，融合了天文观测与农业生产经验。',
                content: '农历详细内容...'
            }
        ];
        this.articles = [];
    },

    renderTerms() {
        const container = document.getElementById('termsGrid');
        if (!container) return;

        let html = '';
        this.terms.forEach(term => {
            html += `
                <div class="knowledge-card" data-term-id="${term.id}">
                    <div class="knowledge-icon">
                        ${this.getIconSVG(term.icon)}
                    </div>
                    <h3 class="knowledge-title">${term.title}</h3>
                    <p class="knowledge-description">${term.description}</p>
                </div>
            `;
        });

        container.innerHTML = html;
        this.bindTermEvents();
    },

    renderArticles() {
        const container = document.getElementById('articlesGrid');
        if (!container) return;

        let html = '';
        this.articles.forEach(article => {
            html += `
                <div class="knowledge-card" data-article-id="${article.id}">
                    <div class="knowledge-icon">
                        ${this.getIconSVG('book')}
                    </div>
                    <h3 class="knowledge-title">${article.title}</h3>
                    <p class="knowledge-description">${article.description}</p>
                </div>
            `;
        });

        container.innerHTML = html;
        this.bindArticleEvents();
    },

    bindTermEvents() {
        const cards = document.querySelectorAll('#termsGrid .knowledge-card');
        cards.forEach(card => {
            card.addEventListener('click', () => {
                const termId = card.dataset.termId;
                this.showTermDetail(termId);
            });
        });
    },

    bindArticleEvents() {
        const cards = document.querySelectorAll('#articlesGrid .knowledge-card');
        cards.forEach(card => {
            card.addEventListener('click', () => {
                const articleId = card.dataset.articleId;
                this.showArticleDetail(articleId);
            });
        });
    },

    showTermDetail(termId) {
        const term = this.terms.find(t => t.id === termId);
        if (!term) return;
        this.createDetailModal(term.title, term.content);
    },

    showArticleDetail(articleId) {
        const article = this.articles.find(a => a.id === articleId);
        if (!article) return;
        this.createDetailModal(article.title, article.content);
    },

    showDetailById(id, type) {
        if (type === '词条') {
            this.showTermDetail(id);
        } else if (type === '文章') {
            this.showArticleDetail(id);
        }
    },

    createDetailModal(title, content) {
        const existingModal = document.getElementById('knowledgeDetailModal');
        if (existingModal) {
            existingModal.remove();
        }

        const modal = document.createElement('div');
        modal.id = 'knowledgeDetailModal';
        modal.className = 'knowledge-modal';
        modal.innerHTML = `
            <div class="knowledge-modal-content">
                <button class="knowledge-modal-close">&times;</button>
                <h2 class="knowledge-modal-title">${title}</h2>
                <div class="knowledge-modal-body">${content.replace(/\n/g, '<br>')}</div>
            </div>
        `;

        document.body.appendChild(modal);

        const closeBtn = modal.querySelector('.knowledge-modal-close');
        closeBtn.addEventListener('click', () => {
            modal.remove();
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        setTimeout(() => {
            modal.classList.add('active');
        }, 10);
    },

    getIconSVG(iconName) {
        const icons = {
            calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 2v20M2 12h20"/>
            </svg>`,
            sun: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>`,
            cycle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>`,
            book: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="16" y1="13" x2="8" y2="13"/>
                <line x1="16" y1="17" x2="8" y2="17"/>
            </svg>`,
            heart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>`,
            clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
            </svg>`
        };

        return icons[iconName] || icons.book;
    }
};
