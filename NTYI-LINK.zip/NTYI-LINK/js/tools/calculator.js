// js/tools/calculator.js - 计算器工具
(function() {
    const CalculatorTool = {
        calcExpression: '',
        modal: null,
        currentMode: 'basic', // 'basic' 或 'scientific'

        init() {
            this.bindEvents();
        },

        bindEvents() {
            // 打开计算器
            const openBtn = document.getElementById('openCalculator');
            if (openBtn) {
                openBtn.addEventListener('click', () => this.show());
            }

            // 关闭计算器
            const closeBtn = document.getElementById('closeCalculator');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => this.hide());
            }

            // 点击背景关闭
            this.modal = document.getElementById('calculatorModal');
            if (this.modal) {
                this.modal.addEventListener('click', (e) => {
                    if (e.target === this.modal) {
                        this.hide();
                    }
                });
            }

            // 计算器按钮 - 使用事件委托，避免重复触发
            const buttonsContainer = document.querySelector('.calculator-container');
            if (buttonsContainer) {
                buttonsContainer.addEventListener('click', (e) => {
                    const button = e.target.closest('.calc-button');
                    if (!button) return;
                    
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const action = button.dataset.action;
                    const value = button.dataset.value;
                    
                    if (action === 'clear') {
                        this.clearCalc();
                    } else if (action === 'delete') {
                        this.deleteLast();
                    } else if (action === 'calculate') {
                        this.calculate();
                    } else if (action === 'append' && value) {
                        this.appendCalc(value);
                    } else if (action === 'function' && value) {
                        this.appendFunction(value);
                    } else if (action === 'constant' && value) {
                        this.appendConstant(value);
                    }
                });
            }
        },

        switchMode(mode) {
            this.currentMode = mode;
            const basicButtons = document.getElementById('basicButtons');
            const scientificButtons = document.getElementById('scientificButtons');
            const basicModeBtn = document.getElementById('basicModeBtn');
            const scientificModeBtn = document.getElementById('scientificModeBtn');
            
            if (mode === 'basic') {
                basicButtons.style.display = 'grid';
                scientificButtons.style.display = 'none';
                basicModeBtn.classList.add('active');
                scientificModeBtn.classList.remove('active');
            } else {
                basicButtons.style.display = 'none';
                scientificButtons.style.display = 'grid';
                basicModeBtn.classList.remove('active');
                scientificModeBtn.classList.add('active');
            }
        },

        show() {
            if (this.modal) {
                this.modal.style.display = 'flex';
            }
        },

        hide() {
            if (this.modal) {
                this.modal.style.display = 'none';
                this.clearCalc();
            }
        },

        appendCalc(value) {
            this.calcExpression += value;
            const display = document.getElementById('calcDisplay');
            if (display) display.value = this.calcExpression;
        },

        clearCalc() {
            this.calcExpression = '';
            const display = document.getElementById('calcDisplay');
            if (display) display.value = '';
        },

        deleteLast() {
            this.calcExpression = this.calcExpression.slice(0, -1);
            const display = document.getElementById('calcDisplay');
            if (display) display.value = this.calcExpression;
        },

        appendFunction(funcName) {
            const funcMap = {
                'sin': 'sin(',
                'cos': 'cos(',
                'tan': 'tan(',
                'log': 'log(',
                'ln': 'ln(',
                'sqrt': 'sqrt('
            };
            
            if (funcMap[funcName]) {
                this.calcExpression += funcMap[funcName];
                const display = document.getElementById('calcDisplay');
                if (display) display.value = this.calcExpression;
            }
        },

        appendConstant(value) {
            const constants = {
                'pi': Math.PI,
                'e': Math.E
            };
            
            if (constants[value] !== undefined) {
                this.calcExpression += constants[value].toString();
                const display = document.getElementById('calcDisplay');
                if (display) display.value = this.calcExpression;
            }
        },

        calculate() {
            try {
                let expression = this.calcExpression;
                
                // 替换数学常数和函数
                expression = expression.replace(/π/g, 'Math.PI');
                expression = expression.replace(/e/g, 'Math.E');
                expression = expression.replace(/sin\(/g, 'Math.sin(');
                expression = expression.replace(/cos\(/g, 'Math.cos(');
                expression = expression.replace(/tan\(/g, 'Math.tan(');
                expression = expression.replace(/log\(/g, 'Math.log10(');
                expression = expression.replace(/ln\(/g, 'Math.log(');
                expression = expression.replace(/sqrt\(/g, 'Math.sqrt(');
                expression = expression.replace(/\^/g, '**');
                
                // 处理阶乘
                expression = this.handleFactorial(expression);
                
                const result = new Function('return ' + expression)();
                const display = document.getElementById('calcDisplay');
                if (display) {
                    // 保留最多10位小数
                    display.value = parseFloat(result.toFixed(10));
                }
                this.calcExpression = result.toString();
            } catch (e) {
                const display = document.getElementById('calcDisplay');
                if (display) {
                    display.value = 'Error';
                }
                console.error('计算错误:', e);
                this.calcExpression = '';
            }
        },

        handleFactorial(expression) {
            // 处理阶乘符号 !
            return expression.replace(/(\d+)!/g, (match, num) => {
                return this.factorial(parseInt(num));
            });
        },

        factorial(n) {
            if (n < 0) return NaN;
            if (n === 0 || n === 1) return 1;
            let result = 1;
            for (let i = 2; i <= n; i++) {
                result *= i;
            }
            return result;
        },

        destroy() {
            // 清理事件监听器等
            this.calcExpression = '';
        }
    };

    // 注册工具
    ToolRegistry.register('calculator', {
        name: '计算器',
        description: '简单易用的在线计算器',
        icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="4" y="2" width="16" height="20" rx="2"/>
            <line x1="8" y1="6" x2="16" y2="6"/>
            <line x1="8" y1="10" x2="16" y2="10"/>
            <line x1="8" y1="14" x2="16" y2="14"/>
            <line x1="8" y1="18" x2="16" y2="18"/>
        </svg>`,
        init: () => CalculatorTool.init(),
        render: () => CalculatorTool.show(),
        destroy: () => CalculatorTool.destroy()
    });
})();