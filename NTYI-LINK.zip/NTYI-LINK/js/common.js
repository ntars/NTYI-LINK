// js/common.js - 公共模块整合
// 包含：主题管理、组件生成、动画管理、PWA功能、SPA路由

// ==================== 主题管理 ====================
const ThemeManager = {
    init() {
        this.applyInitialTheme();
        this.watchSystemTheme();
    },

    applyInitialTheme() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            document.documentElement.setAttribute('data-theme', savedTheme);
        } else {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            const theme = prefersDark ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', theme);
        }
    },

    watchSystemTheme() {
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (!localStorage.getItem('theme')) {
                const theme = e.matches ? 'dark' : 'light';
                document.documentElement.setAttribute('data-theme', theme);
            }
        });
    },

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    },

    getCurrentTheme() {
        return document.documentElement.getAttribute('data-theme');
    }
};

// ==================== 组件生成器 ====================
const ComponentGenerator = {
    pages: [
        { name: '今日', url: 'index.html', icon: 'home' },
        { name: '搜索', url: 'search.html', icon: 'search' },
        { name: '知识', url: 'knowledge.html', icon: 'book' },
        { name: '工具', url: 'tools.html', icon: 'tool' }
    ],

    generateNavbar(currentPage) {
        const navIcons = {
            home: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>`,
            search: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>`,
            book: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
            </svg>`,
            tool: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
            </svg>`
        };
        
        const navLinks = this.pages.map(page => {
            const isActive = page.url === currentPage ? ' active' : '';
            const icon = navIcons[page.icon] || '';
            return `<button class="nav-link${isActive}" data-page="${page.url}">${icon}<span>${page.name}</span></button>`;
        }).join('');

        return `
            <nav class="navbar">
                <div class="nav-container">
                    <button class="logo" data-page="index.html">
                        <svg width="32" height="32" viewBox="0 0 64 64" fill="currentColor">
                            <g transform="matrix(0.051613,0,0,0.051613,-19.612854,-18.645142)">
                                <path d="M1454.685,662.49L1519.615,700L1519.615,1300L1064.95,1562.501L1064.95,1409.808L1389.524,1225.108L1389.524,1064.95L1037.531,1065.005L1112.592,934.995L1389.524,934.995L1389.716,700L1454.685,662.49Z"/>
                                <path d="M480.385,700L545.354,662.49L935.05,887.498L935.05,437.499L1000,400L1064.95,437.499L1064.95,962.501L935.05,1037.499L610.289,849.984L610.289,1225L480.385,1300L480.385,700Z"/>
                            </g>
                        </svg>
                        <span>玄玖灵犀</span>
                    </button>
                    <div class="nav-links">
                        ${navLinks}
                    </div>
                </div>
            </nav>
        `;
    },

    generateBottomNav() {
        return `
            <div class="bottom-nav">
                <button class="nav-button" id="backButton" aria-label="返回上一级">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <button class="nav-button" id="homeButton" aria-label="返回主页">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                </button>
                <button class="nav-button theme-toggle" id="themeToggle" aria-label="切换主题">
                    <svg class="sun-icon" viewBox="0 0 24 24" fill="currentColor">
                        <circle cx="12" cy="12" r="5"></circle>
                        <line x1="12" y1="1" x2="12" y2="3" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="12" y1="21" x2="12" y2="23" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="1" y1="12" x2="3" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="21" y1="12" x2="23" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
                    </svg>
                    <svg class="moon-icon" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                    </svg>
                </button>
            </div>
        `;
    },

    renderComponents(currentPage) {
        const navbarHTML = this.generateNavbar(currentPage);
        document.body.insertAdjacentHTML('afterbegin', navbarHTML);

        const bottomNavHTML = this.generateBottomNav();
        document.body.insertAdjacentHTML('beforeend', bottomNavHTML);
    }
};

// ==================== 动画管理 ====================
const AnimationManager = {
    initPageTransition() {
        document.addEventListener('click', (e) => {
            const link = e.target.closest('.nav-link');
            
            if (!link || link.classList.contains('active')) {
                return;
            }
            
            e.preventDefault();
            const targetUrl = link.href;
            
            this.fadeOut(() => {
                window.location.href = targetUrl;
            });
        });
    },

    fadeOut(callback) {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '0';
        
        setTimeout(() => {
            if (callback) callback();
        }, 300);
    },

    fadeIn() {
        document.body.style.opacity = '1';
        document.body.style.transition = '';
    },

    initScrollBounce() {
        let wrapper = document.querySelector('.content-wrapper');
        if (!wrapper) {
            wrapper = document.createElement('div');
            wrapper.className = 'content-wrapper';
            
            const mainContainer = document.querySelector('.main-container');
            if (mainContainer) {
                mainContainer.parentNode.insertBefore(wrapper, mainContainer);
                wrapper.appendChild(mainContainer);
            }
        }

        let isAtTop = false;
        let isAtBottom = false;
        let startY = 0;
        let currentY = 0;
        let isDragging = false;

        document.addEventListener('touchstart', (e) => {
            startY = e.touches[0].clientY;
            isDragging = true;
            
            const scrollTop = window.scrollY || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight;
            const clientHeight = document.documentElement.clientHeight;
            
            isAtTop = scrollTop <= 0;
            isAtBottom = scrollTop + clientHeight >= scrollHeight - 1;
        }, { passive: true });

        document.addEventListener('touchmove', (e) => {
            if (!isDragging) return;
            
            currentY = e.touches[0].clientY;
            const deltaY = currentY - startY;
            
            const scrollTop = window.scrollY || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight;
            const clientHeight = document.documentElement.clientHeight;
            
            if (isAtTop && deltaY > 0 && scrollTop <= 0) {
                e.preventDefault();
                const resistance = Math.max(0, 1 - deltaY / 500);
                const translate = deltaY * resistance * 0.5;
                wrapper.style.transform = `translateY(${translate}px)`;
                wrapper.style.transition = 'none';
            }
            
            if (isAtBottom && deltaY < 0 && scrollTop + clientHeight >= scrollHeight - 1) {
                e.preventDefault();
                const resistance = Math.max(0, 1 + deltaY / 500);
                const translate = deltaY * resistance * 0.5;
                wrapper.style.transform = `translateY(${translate}px)`;
                wrapper.style.transition = 'none';
            }
        }, { passive: false });

        document.addEventListener('touchend', () => {
            if (!isDragging) return;
            isDragging = false;
            
            wrapper.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
            wrapper.style.transform = 'translateY(0)';
            
            setTimeout(() => {
                wrapper.style.transform = '';
                wrapper.style.transition = '';
            }, 400);
        });

        let wheelTimer = null;
        document.addEventListener('wheel', (e) => {
            const scrollTop = window.scrollY || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight;
            const clientHeight = document.documentElement.clientHeight;
            
            if (scrollTop <= 0 && e.deltaY < 0) {
                e.preventDefault();
                const translate = Math.min(50, Math.abs(e.deltaY) * 0.3);
                wrapper.style.transform = `translateY(${translate}px)`;
                wrapper.style.transition = 'none';
                
                clearTimeout(wheelTimer);
                wheelTimer = setTimeout(() => {
                    wrapper.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
                    wrapper.style.transform = 'translateY(0)';
                    setTimeout(() => {
                        wrapper.style.transform = '';
                        wrapper.style.transition = '';
                    }, 400);
                }, 100);
            }
            
            if (scrollTop + clientHeight >= scrollHeight - 1 && e.deltaY > 0) {
                e.preventDefault();
                const translate = Math.max(-50, -Math.abs(e.deltaY) * 0.3);
                wrapper.style.transform = `translateY(${translate}px)`;
                wrapper.style.transition = 'none';
                
                clearTimeout(wheelTimer);
                wheelTimer = setTimeout(() => {
                    wrapper.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
                    wrapper.style.transform = 'translateY(0)';
                    setTimeout(() => {
                        wrapper.style.transform = '';
                        wrapper.style.transition = '';
                    }, 400);
                }, 100);
            }
        }, { passive: false });
    }
};

// ==================== PWA 功能 ====================
const PWAManager = {
    init() {
        this.registerServiceWorker();
        this.setupOfflineDetection();
    },

    registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then((registration) => {
                        console.log('Service Worker注册成功:', registration.scope);
                    })
                    .catch((error) => {
                        console.log('Service Worker注册失败:', error);
                    });
            });
        }
    },

    setupOfflineDetection() {
        window.addEventListener('online', () => {
            console.log('网络已连接');
        });

        window.addEventListener('offline', () => {
            console.log('网络已断开，使用离线模式');
        });
    }
};

// ==================== SPA 路由管理器 ====================
const SPARouter = {
    currentPage: 'index',

    pages: {
        'index': { id: 'page-index', title: '今日' },
        'search': { id: 'page-search', title: '搜索' },
        'knowledge': { id: 'page-knowledge', title: '知识' },
        'tools': { id: 'page-tools', title: '工具' }
    },

    init() {
        this.bindNavigationEvents();
        this.updateURL('index');
        // 初始化首页功能（包括万年历）
        this.initPageFeatures('index');
    },

    bindNavigationEvents() {
        // 监听导航栏点击
        document.addEventListener('click', (e) => {
            const link = e.target.closest('.nav-link');
            if (!link) return;

            e.preventDefault();
            const pageName = this.getPageNameFromLink(link);
            if (pageName && pageName !== this.currentPage) {
                this.navigateTo(pageName);
            }
        });

        // 监听返回按钮
        const backButton = document.getElementById('backButton');
        if (backButton) {
            backButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.goBack();
            });
        }

        // 监听主页按钮
        const homeButton = document.getElementById('homeButton');
        if (homeButton) {
            homeButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.goHome();
            });
        }
    },

    getPageNameFromLink(link) {
        const pageUrl = link.getAttribute('data-page');
        if (pageUrl === 'index.html') return 'index';
        if (pageUrl === 'search.html') return 'search';
        if (pageUrl === 'knowledge.html') return 'knowledge';
        if (pageUrl === 'tools.html') return 'tools';
        return null;
    },

    navigateTo(pageName) {
        if (!this.pages[pageName]) {
            console.error(`页面不存在: ${pageName}`);
            return;
        }

        // 隐藏所有页面
        Object.values(this.pages).forEach(page => {
            const element = document.getElementById(page.id);
            if (element) {
                element.classList.remove('active');
            }
        });

        // 显示目标页面
        const targetPage = document.getElementById(this.pages[pageName].id);
        if (targetPage) {
            targetPage.classList.add('active');
        }

        // 更新导航栏激活状态
        this.updateNavActiveState(pageName);

        // 更新当前页面
        this.currentPage = pageName;

        // 更新URL
        this.updateURL(pageName);

        // 初始化页面特定功能
        this.initPageFeatures(pageName);

        // 滚动到顶部
        window.scrollTo(0, 0);
    },

    goHome() {
        if (this.currentPage !== 'index') {
            this.navigateTo('index');
        } else {
            if (window.location.hash) {
                window.history.pushState({ page: 'index' }, '', '');
            }
        }
    },

    goBack() {
        if (this.currentPage !== 'index') {
            this.navigateTo('index');
        }
    },

    updateNavActiveState(pageName) {
        const links = document.querySelectorAll('.nav-link');
        links.forEach(link => {
            link.classList.remove('active');
            const pageUrl = link.getAttribute('data-page');
            if ((pageName === 'index' && pageUrl === 'index.html') ||
                (pageName === 'search' && pageUrl === 'search.html') ||
                (pageName === 'knowledge' && pageUrl === 'knowledge.html') ||
                (pageName === 'tools' && pageUrl === 'tools.html')) {
                link.classList.add('active');
            }
        });
    },

    updateURL(pageName) {
        const hashMap = {
            'index': '',
            'search': '#search',
            'knowledge': '#knowledge',
            'tools': '#tools'
        };
        
        const hash = hashMap[pageName] || '';
        
        if (window.location.hash !== hash) {
            if (hash === '') {
                window.history.replaceState({ page: pageName }, '', window.location.pathname + window.location.search);
            } else {
                window.history.replaceState({ page: pageName }, '', hash);
            }
        }
    },

    initPageFeatures(pageName) {
        switch (pageName) {
            case 'index':
                if (typeof WeatherModule !== 'undefined') {
                    WeatherModule.init();
                }
                if (typeof AlmanacModule !== 'undefined') {
                    AlmanacModule.init();
                }
                break;
            case 'search':
                if (typeof SearchPageManager !== 'undefined') {
                    SearchPageManager.init();
                }
                break;
            case 'knowledge':
                if (typeof KnowledgeManager !== 'undefined') {
                    KnowledgeManager.init();
                }
                break;
            case 'tools':
                if (typeof ToolsPageManager !== 'undefined') {
                    ToolsPageManager.init();
                }
                break;
        }
    },

    handlePopState(event) {
        if (event.state && event.state.page) {
            const pageName = event.state.page;
            const targetPageElement = document.getElementById(this.pages[pageName].id);
            
            if (!targetPageElement) return;

            // 隐藏所有页面
            Object.values(this.pages).forEach(page => {
                const element = document.getElementById(page.id);
                if (element) {
                    element.classList.remove('active', 'leaving');
                }
            });

            // 显示目标页面
            targetPageElement.classList.add('active');

            this.updateNavActiveState(pageName);
            this.currentPage = pageName;
            this.initPageFeatures(pageName);
            
            window.scrollTo(0, 0);
            
            if (pageName === 'index' && window.location.hash) {
                window.history.replaceState({ page: 'index' }, '', window.location.pathname + window.location.search);
            }
        } else {
            if (window.location.hash) {
                this.navigateTo('index');
            }
        }
    }
};

// 监听浏览器前进后退
window.addEventListener('popstate', (event) => {
    SPARouter.handlePopState(event);
});

// ==================== 主初始化器 ====================
const AppInitializer = {
    init(currentPage) {
        // 1. 初始化主题管理（最优先，防止闪烁）
        ThemeManager.init();

        // 2. 渲染公共组件（导航栏和底部按钮）
        ComponentGenerator.renderComponents(currentPage === 'spa' ? 'index.html' : currentPage);

        // 3. 绑定事件处理器
        this.bindEventHandlers();

        // 4. 初始化PWA功能
        PWAManager.init();

        // 5. 应用安全限制
        this.applySecurityRestrictions();

        // 6. 根据模式初始化
        if (currentPage === 'spa') {
            this.initSPAMode();
        } else {
            this.initMultiPageMode(currentPage);
        }

        // 7. 恢复页面可见性（最后执行，确保所有内容已准备好）
        this.restoreVisibility();

        console.log('NTYI-LINK 应用初始化完成');
    },

    restoreVisibility() {
        if (typeof SPARouter === 'undefined') {
            AnimationManager.fadeIn();
        }
    },

    bindEventHandlers() {
        bindThemeToggle();
    },

    applySecurityRestrictions() {
        disableContextMenu();
        disableCopyPaste();
    },

    initSPAMode() {
        // 开屏动画处理
        this.handleSplashScreen();
        
        if (typeof IndexPageManager !== 'undefined' && !IndexPageManager.initialized) {
            IndexPageManager.init();
            IndexPageManager.initialized = true;
        }
        
        AnimationManager.initScrollBounce();
        
        if (typeof SPARouter !== 'undefined') {
            SPARouter.init();
        }
    },
    
    handleSplashScreen() {
        const splashScreen = document.getElementById('splash-screen');
        if (!splashScreen) return;
        
        setTimeout(() => {
            splashScreen.classList.add('hidden');
            
            setTimeout(() => {
                splashScreen.style.display = 'none';
            }, 400);
        }, 2000);
    },

    initMultiPageMode(currentPage) {
        AnimationManager.initPageTransition();
        AnimationManager.initScrollBounce();
        this.initPageSpecificFeatures(currentPage);
    },

    initPageSpecificFeatures(currentPage) {
        switch (currentPage) {
            case 'index.html':
                if (typeof IndexPageManager !== 'undefined') {
                    IndexPageManager.init();
                }
                break;
            case 'search.html':
                if (typeof SearchPageManager !== 'undefined') {
                    SearchPageManager.init();
                }
                break;
            case 'tools.html':
                if (typeof ToolsPageManager !== 'undefined') {
                    ToolsPageManager.init();
                }
                break;
            case 'knowledge.html':
                break;
            default:
                console.log(`未知页面: ${currentPage}`);
        }
    }
};

// 全局兼容接口
const CommonComponents = {
    init(currentPage) {
        AppInitializer.init(currentPage);
    }
};
