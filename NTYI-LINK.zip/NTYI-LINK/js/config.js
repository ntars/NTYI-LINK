// js/config.js - 配置和工具注册
// 包含：工具注册中心、工具页管理器

// ==================== 工具注册中心 ====================
const ToolRegistry = {
    tools: {},

    register(id, toolConfig) {
        this.tools[id] = {
            id: id,
            name: toolConfig.name,
            description: toolConfig.description,
            icon: toolConfig.icon,
            init: toolConfig.init,
            render: toolConfig.render,
            destroy: toolConfig.destroy
        };
        console.log(`工具已注册: ${id}`);
    },

    getAllTools() {
        return Object.values(this.tools);
    },

    getTool(id) {
        return this.tools[id];
    },

    initTool(id) {
        const tool = this.tools[id];
        if (tool && tool.init) {
            tool.init();
        }
    },

    destroyTool(id) {
        const tool = this.tools[id];
        if (tool && tool.destroy) {
            tool.destroy();
        }
    }
};

// ==================== 工具页功能模块 ====================
const ToolsPageManager = {
    init() {
        this.renderToolsGrid();
    },

    renderToolsGrid() {
        const container = document.getElementById('toolsGrid');
        if (!container) return;

        const tools = ToolRegistry.getAllTools();
        let html = '';

        tools.forEach(tool => {
            html += `
                <div class="tool-card" id="open${this.capitalizeFirst(tool.id)}">
                    <div class="tool-icon">
                        ${tool.icon}
                    </div>
                    <h3 class="tool-name">${tool.name}</h3>
                    <p class="tool-description">${tool.description}</p>
                </div>
            `;
        });

        container.innerHTML = html;

        // 初始化工具
        tools.forEach(tool => {
            ToolRegistry.initTool(tool.id);
        });
    },

    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
};
