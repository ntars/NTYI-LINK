// js/modules/weather.js - 天气模块
const WeatherModule = {
    // 当前天气信息
    weatherInfo: null,
    
    // API超时时间（毫秒）
    apiTimeout: 5000,
    
    // 天气API列表（按优先级排序）
    weatherAPIs: [
        {
            name: 'wttr.in',
            type: 'open-source',
            source: 'https://github.com/chubin/wttr.in',
            description: '开源天气服务，无需API密钥',
            fetch: (lat, lon) => fetch(`https://wttr.in/${lat},${lon}?format=j1&lang=zh`, { mode: 'cors' }),
            parse: (data) => {
                const current = data.current_condition[0];
                return {
                    temperature: current.temp_C,
                    feelsLike: current.FeelsLikeC,
                    humidity: current.humidity,
                    windSpeed: current.windspeedKmph,
                    windDirection: current.winddir16Point,
                    description: current.lang_zh ? current.lang_zh[0].value : current.weatherDesc[0].value,
                    iconCode: current.weatherCode
                };
            }
        },
        {
            name: 'Open-Meteo',
            type: 'open-source',
            source: 'https://open-meteo.com/',
            description: '开源气象API，无需API密钥',
            fetch: (lat, lon) => fetch(
                `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m&timezone=auto`,
                { mode: 'cors' }
            ),
            parse: (data) => {
                const current = data.current;
                return {
                    temperature: Math.round(current.temperature_2m),
                    feelsLike: Math.round(current.apparent_temperature),
                    humidity: current.relative_humidity_2m,
                    windSpeed: current.wind_speed_10m,
                    windDirection: this.getWindDirectionFromDegrees(current.wind_direction_10m),
                    description: this.getWeatherDescriptionFromWMO(current.weather_code),
                    iconCode: this.convertWMOToWttrCode(current.weather_code)
                };
            }
        }
    ],
    
    // 当前使用的API索引
    currentAPIIndex: 0,
    
    // SVG图标
    icons: {
        sun: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="5"/>
                <line x1="12" y1="1" x2="12" y2="3"/>
                <line x1="12" y1="21" x2="12" y2="23"/>
                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                <line x1="1" y1="12" x2="3" y2="12"/>
                <line x1="21" y1="12" x2="23" y2="12"/>
                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>`,
        cloud: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
            </svg>`,
        partlyCloudy: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="4"/>
                <path d="M18 14h-1.26A8 8 0 1 0 9 22h9a5 5 0 0 0 0-10z"/>
            </svg>`,
        rain: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
                <line x1="8" y1="22" x2="8" y2="24"/>
                <line x1="12" y1="22" x2="12" y2="24"/>
                <line x1="16" y1="22" x2="16" y2="24"/>
            </svg>`,
        snow: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
                <line x1="8" y1="22" x2="8" y2="24"/>
                <line x1="12" y1="22" x2="12" y2="24"/>
                <line x1="16" y1="22" x2="16" y2="24"/>
            </svg>`,
        thunder: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
            </svg>`,
        fog: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" opacity="0.5"/>
                <line x1="4" y1="22" x2="20" y2="22"/>
                <line x1="6" y1="24" x2="18" y2="24"/>
            </svg>`,
        location: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
            </svg>`,
        weather: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
            </svg>`
    },
    
    // 初始化模块
    init() {
        console.log('天气模块开始初始化...');
        this.fetchWeatherData().then(() => {
            this.renderWeather();
            console.log('天气模块初始化成功');
        }).catch(error => {
            console.error('天气数据加载失败:', error);
            this.renderWeather();
        });
    },
    
    // 获取天气数据
    async fetchWeatherData() {
        try {
            // 首先获取用户位置
            const position = await this.getUserLocation();
            if (!position) {
                throw new Error('无法获取位置信息');
            }
            
            const { lat, lon, cityName } = position;
            
            // 尝试多个API，直到成功
            let lastError = null;
            for (let i = 0; i < this.weatherAPIs.length; i++) {
                const api = this.weatherAPIs[i];
                this.currentAPIIndex = i;
                
                try {
                    console.log(`尝试使用 ${api.name} (${api.type === 'open-source' ? '开源' : '免费'})...`);
                    
                    let response;
                    if (api.apiKey) {
                        response = await this.fetchWithTimeout(
                            api.fetch(lat, lon, api.apiKey),
                            this.apiTimeout
                        );
                    } else {
                        response = await this.fetchWithTimeout(
                            api.fetch(lat, lon),
                            this.apiTimeout
                        );
                    }
                    
                    if (!response.ok) {
                        throw new Error(`${api.name} API请求失败: ${response.status}`);
                    }
                    
                    const data = await response.json();
                    const parsed = api.parse(data);
                    
                    this.weatherInfo = {
                        ...parsed,
                        icon: this.getWeatherIconFromWttrCode(parsed.iconCode),
                        location: cityName || '当前位置',
                        source: api.name,
                        sourceType: api.type,
                        sourceUrl: api.source
                    };
                    
                    console.log(`天气数据加载完成 (${api.name}):`, this.weatherInfo.location);
                    return; // 成功则退出循环
                    
                } catch (error) {
                    console.warn(`${api.name} 失败:`, error.message);
                    lastError = error;
                    // 继续尝试下一个API
                }
            }
            
            // 所有API都失败
            throw new Error(`所有天气API均失败: ${lastError?.message}`);
            
        } catch (error) {
            console.warn('天气API调用失败，使用默认数据:', error);
            this.weatherInfo = this.getDefaultWeatherData();
        }
    },
    
    // 带超时的fetch包装器
    fetchWithTimeout(promise, timeout) {
        return Promise.race([
            promise,
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('请求超时')), timeout)
            )
        ]);
    },
    
    // 获取用户位置
    getUserLocation() {
        return new Promise((resolve) => {
            if (!navigator.geolocation) {
                resolve({ lat: 39.9042, lon: 116.4074, cityName: '北京' }); // 默认北京
                return;
            }
            
            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    
                    // 使用反向地理编码获取城市名
                    try {
                        const response = await this.fetchWithTimeout(
                            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&accept-language=zh-CN`, { mode: 'cors' }),
                            5000
                        );
                        const data = await response.json();
                        const cityName = data.address?.city || data.address?.town || data.address?.county || '未知城市';
                        resolve({ lat, lon, cityName });
                    } catch (e) {
                        resolve({ lat, lon, cityName: '当前位置' });
                    }
                },
                (error) => {
                    console.warn('位置获取失败:', error);
                    resolve({ lat: 39.9042, lon: 116.4074, cityName: '北京' }); // 默认北京
                },
                { timeout: 5000 }
            );
        });
    },
    
    // 根据风向角度获取方向名称
    getWindDirection(degrees) {
        const directions = ['北', '东北', '东', '东南', '南', '西南', '西', '西北'];
        const index = Math.round(degrees / 45) % 8;
        return directions[index];
    },
    
    // 从度数获取风向（Open-Meteo用）
    getWindDirectionFromDegrees(degrees) {
        return this.getWindDirection(degrees);
    },
    
    // 从WMO代码获取天气描述（Open-Meteo用）
    getWeatherDescriptionFromWMO(code) {
        const wmoMap = {
            0: '晴天',
            1: '主要晴朗',
            2: '多云',
            3: '阴天',
            45: '雾',
            48: '雾凇',
            51: '小毛毛雨',
            53: '中毛毛雨',
            55: '大毛毛雨',
            61: '小雨',
            63: '中雨',
            65: '大雨',
            71: '小雪',
            73: '中雪',
            75: '大雪',
            95: '雷雨',
            96: '雷阵雨带冰雹',
            99: '强雷阵雨带冰雹'
        };
        return wmoMap[code] || '未知天气';
    },
    

    
    // 根据wttr.in天气代码获取SVG图标
    getWeatherIconFromWttrCode(code) {
        const iconMap = {
            '113': this.icons.sun,           // 晴天
            '116': this.icons.partlyCloudy,  // 少云
            '119': this.icons.cloud,         // 多云
            '122': this.icons.cloud,         // 阴天
            '143': this.icons.fog,           // 雾
            '176': this.icons.rain,          // 小雨
            '179': this.icons.snow,          // 小雪
            '182': this.icons.rain,          // 雨夹雪
            '227': this.icons.snow,          // 大雪
            '230': this.icons.snow,          // 暴雪
            '248': this.icons.fog,           // 薄雾
            '260': this.icons.fog,           // 浓雾
            '263': this.icons.rain,          // 小阵雨
            '266': this.icons.rain,          // 小雨
            '281': this.icons.rain,          // 冻雨
            '284': this.icons.rain,          // 大冻雨
            '293': this.icons.rain,          // 小阵雨
            '296': this.icons.rain,          // 小雨
            '299': this.icons.rain,          // 中雨
            '302': this.icons.rain,          // 大雨
            '305': this.icons.rain,          // 暴雨
            '308': this.icons.rain,          // 特大暴雨
            '311': this.icons.rain,          // 冻雨
            '314': this.icons.rain,          // 大冻雨
            '317': this.icons.rain,          // 雨夹雪
            '320': this.icons.snow,          // 小雪
            '323': this.icons.snow,          // 阵雪
            '326': this.icons.snow,          // 小雪
            '329': this.icons.snow,          // 中雪
            '332': this.icons.snow,          // 大雪
            '335': this.icons.snow,          // 暴雪
            '338': this.icons.snow,          // 大暴雪
            '350': this.icons.rain,          // 冰粒
            '353': this.icons.rain,          // 小阵雨
            '356': this.icons.rain,          // 中阵雨
            '359': this.icons.rain,          // 大阵雨
            '362': this.icons.rain,          // 小雨夹雪
            '365': this.icons.rain,          // 大雨夹雪
            '368': this.icons.snow,          // 小阵雪
            '371': this.icons.snow,          // 大阵雪
            '374': this.icons.rain,          // 小冰雹
            '377': this.icons.rain,          // 大冰雹
            '386': this.icons.thunder,       // 雷阵雨
            '389': this.icons.thunder,       // 大雷雨
            '392': this.icons.thunder,       // 雷阵雪
            '395': this.icons.thunder        // 大雷阵雪
        };
        return iconMap[code] || this.icons.partlyCloudy;
    },
    
    // 默认天气数据
    getDefaultWeatherData() {
        return {
            temperature: '--',
            feelsLike: '--',
            humidity: '--',
            windSpeed: '--',
            windDirection: '--',
            description: '暂无数据',
            icon: this.icons.cloud,
            location: '未知位置',
            source: '本地数据',
            sourceType: 'fallback',
            sourceUrl: null
        };
    },
    
    // 渲染天气卡片
    renderWeather() {
        const container = document.getElementById('weather-container');
        if (!container) return;
        
        if (!this.weatherInfo) {
            container.innerHTML = `
                <div class="weather-card">
                    <div class="weather-icon">${this.icons.weather}</div>
                    <div class="weather-info">
                        <div class="weather-temp">加载中...</div>
                        <div class="weather-desc">正在获取天气数据</div>
                    </div>
                </div>
            `;
            return;
        }
        
        // 数据来源标注
        const sourceBadge = this.weatherInfo.sourceType === 'open-source' 
            ? `<span class="source-badge open-source" title="开源项目: ${this.weatherInfo.sourceUrl}">${this.weatherInfo.source}</span>`
            : this.weatherInfo.sourceType === 'freemium'
            ? `<span class="source-badge freemium" title="免费服务: ${this.weatherInfo.sourceUrl}">${this.weatherInfo.source}</span>`
            : `<span class="source-badge fallback">${this.weatherInfo.source}</span>`;
        
        container.innerHTML = `
            <div class="weather-card">
                <div class="weather-icon">${this.weatherInfo.icon}</div>
                <div class="weather-info">
                    <div class="weather-location">
                        ${this.icons.location} ${this.weatherInfo.location}
                    </div>
                    <div class="weather-temp">${this.weatherInfo.temperature}°C</div>
                    <div class="weather-desc">${this.weatherInfo.description}</div>
                    <div class="weather-details">
                        <span>体感 ${this.weatherInfo.feelsLike}°C</span>
                        <span>湿度 ${this.weatherInfo.humidity}%</span>
                        <span>${this.weatherInfo.windDirection}风 ${this.weatherInfo.windSpeed}km/h</span>
                    </div>
                    <div class="weather-source">
                        ${sourceBadge}
                    </div>
                </div>
            </div>
        `;
    },
    
    // 刷新天气数据
    refresh() {
        console.log('刷新天气数据...');
        this.fetchWeatherData().then(() => {
            this.renderWeather();
            console.log('天气数据刷新完成');
        }).catch(error => {
            console.error('天气数据刷新失败:', error);
        });
    },
    
    // 销毁模块
    destroy() {
        console.log('天气模块已销毁');
        this.weatherInfo = null;
    }
};
