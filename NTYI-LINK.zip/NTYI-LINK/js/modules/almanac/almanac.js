/**
 * 万年历模块 - 参考布局版 v5.1
 * 使用 lunar-javascript 库进行本地计算
 */
const AlmanacModule = {
    _initialized: false,
    currentData: null,
    
    // 时辰名称
    shichenNames: ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'],
    
    // 星期映射
    weekNames: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
    
    init() {
        if (this._initialized) return;
        
        if (typeof Lunar === 'undefined' || typeof Solar === 'undefined') {
            console.error('[万年历] Lunar库未加载');
            this.showError('Lunar库未加载，请刷新页面');
            return;
        }
        
        this.loadData().then(() => {
            this._initialized = true;
        }).catch(err => {
            console.error('[万年历] 初始化失败:', err);
        });
    },
    
    getDateData(year, month, day) {
        try {
            const solar = Solar.fromYmd(year, month, day);
            const lunar = solar.getLunar();
            
            const weekNum = solar.getWeek();
            const lunarMonthName = lunar.getMonthInChinese() || '';
            const lunarDayName = lunar.getDayInChinese() || '';
            const times = lunar.getTimes ? lunar.getTimes() : [];
            
            const yearZhi = lunar.getYearZhi ? lunar.getYearZhi() : '';
            const monthZhi = lunar.getMonthZhi ? lunar.getMonthZhi() : '';
            const dayZhi = lunar.getDayZhi ? lunar.getDayZhi() : '';
            const hourZhi = lunar.getTimeZhi ? lunar.getTimeZhi() : '';
            
            const ganzhi = {
                year: lunar.getYearInGanZhi ? lunar.getYearInGanZhi() : '',
                yearGan: lunar.getYearGan ? lunar.getYearGan() : '',
                yearZhi,
                month: lunar.getMonthInGanZhi ? lunar.getMonthInGanZhi() : '',
                monthGan: lunar.getMonthGan ? lunar.getMonthGan() : '',
                monthZhi,
                day: lunar.getDayInGanZhi ? lunar.getDayInGanZhi() : '',
                dayGan: lunar.getDayGan ? lunar.getDayGan() : '',
                dayZhi,
                hour: lunar.getTimeInGanZhi ? lunar.getTimeInGanZhi() : '',
                hourGan: lunar.getTimeGan ? lunar.getTimeGan() : '',
                hourZhi,
                yearHideGan: lunar.getYearHideGan ? lunar.getYearHideGan() : [],
                monthHideGan: lunar.getMonthHideGan ? lunar.getMonthHideGan() : [],
                dayHideGan: lunar.getDayHideGan ? lunar.getDayHideGan() : [],
                hourHideGan: lunar.getTimeHideGan ? lunar.getTimeHideGan() : [],
                baZiShiShenDay: lunar.getBaZiShiShenDay ? lunar.getBaZiShiShenDay() : ''
            };
            
            const weekNumber = this.getWeekNumber(year, month, day);
            
            return {
                solar: {
                    year, month, day,
                    week: this.weekNames[weekNum] || '',
                    weekNum,
                    festivals: solar.getFestivals() || [],
                    otherFestivals: solar.getOtherFestivals ? solar.getOtherFestivals() : [],
                    constellation: solar.getXingzuo ? solar.getXingzuo() : '',
                    jieQi: lunar.getJieQi ? lunar.getJieQi() : '',
                    currentJieQi: lunar.getCurrentJieQi ? lunar.getCurrentJieQi() : '',
                    nextJie: lunar.getNextJie ? lunar.getNextJie() : null,
                    nextQi: lunar.getNextQi ? lunar.getNextQi() : null,
                    isWeekend: weekNum === 0 || weekNum === 6,
                    weekNumber
                },
                lunar: {
                    year: lunar.getYear(),
                    month: lunar.getMonth(),
                    day: lunar.getDay(),
                    monthName: lunarMonthName,
                    dayName: lunarDayName,
                    date: (lunar.isLeapMonth ? '闰' : '') + lunarMonthName + '月' + lunarDayName,
                    zodiac: lunar.getShengxiao ? lunar.getShengxiao() : '',
                    isLeapMonth: lunar.isLeapMonth ? lunar.isLeapMonth() : false,
                    festivals: lunar.getFestivals ? lunar.getFestivals() : [],
                    yearInChinese: lunar.getYearInChinese ? lunar.getYearInChinese() : '',
                    season: lunar.getSeason ? lunar.getSeason() : ''
                },
                ganzhi,
                naYin: {
                    year: lunar.getYearNaYin ? lunar.getYearNaYin() : '',
                    month: lunar.getMonthNaYin ? lunar.getMonthNaYin() : '',
                    day: lunar.getDayNaYin ? lunar.getDayNaYin() : '',
                    hour: lunar.getTimeNaYin ? lunar.getTimeNaYin() : ''
                },
                wuXing: this.getWuXingFromZhi(ganzhi.yearZhi, ganzhi.monthZhi, ganzhi.dayZhi, ganzhi.hourZhi),
                nineStar: {
                    year: lunar.getYearNineStar ? lunar.getYearNineStar() : '',
                    month: lunar.getMonthNineStar ? lunar.getMonthNineStar() : '',
                    day: lunar.getDayNineStar ? lunar.getDayNineStar() : '',
                    hour: lunar.getTimeNineStar ? lunar.getTimeNineStar() : ''
                },
                xun: {
                    year: lunar.getYearXun ? lunar.getYearXun() : '',
                    month: lunar.getMonthXun ? lunar.getMonthXun() : '',
                    day: lunar.getDayXun ? lunar.getDayXun() : '',
                    yearKong: lunar.getYearXunKong ? lunar.getYearXunKong() : '',
                    monthKong: lunar.getMonthXunKong ? lunar.getMonthXunKong() : '',
                    dayKong: lunar.getDayXunKong ? lunar.getDayXunKong() : ''
                },
                yiJi: {
                    dayYi: lunar.getDayYi ? lunar.getDayYi() : [],
                    dayJi: lunar.getDayJi ? lunar.getDayJi() : [],
                    timesYiJi: this.getTimesYiJi(times)
                },
                shensha: {
                    good: lunar.getDayJiShen ? lunar.getDayJiShen() : [],
                    bad: lunar.getDayXiongSha ? lunar.getDayXiongSha() : []
                },
                position: {
                    tai: lunar.getDayPositionTai ? lunar.getDayPositionTai() : '',
                    cai: lunar.getDayPositionCai ? lunar.getDayPositionCai() : '',
                    fu: lunar.getDayPositionFu ? lunar.getDayPositionFu() : '',
                    xi: lunar.getDayPositionXi ? lunar.getDayPositionXi() : '',
                    yangGui: lunar.getDayPositionYangGui ? lunar.getDayPositionYangGui() : '',
                    yinGui: lunar.getDayPositionYinGui ? lunar.getDayPositionYinGui() : ''
                },
                chongSha: {
                    dayChong: lunar.getDayChong ? lunar.getDayChong() : '',
                    dayChongDesc: lunar.getDayChongDesc ? lunar.getDayChongDesc() : '',
                    daySha: lunar.getDaySha ? lunar.getDaySha() : ''
                },
                xiu: {
                    name: lunar.getXiu ? lunar.getXiu() : '',
                    luck: lunar.getXiuLuck ? lunar.getXiuLuck() : ''
                },
                jianchu: {
                    zhiXing: lunar.getZhiXing ? lunar.getZhiXing() : '',
                    liuYao: lunar.getLiuYao ? lunar.getLiuYao() : ''
                },
                pengZu: {
                    gan: lunar.getPengZuGan ? lunar.getPengZuGan() : '',
                    zhi: lunar.getPengZuZhi ? lunar.getPengZuZhi() : ''
                },
                taiWu: {
                    taiShen: lunar.getTaiShen ? lunar.getTaiShen() : '',
                    yueXiang: lunar.getYueXiang ? lunar.getYueXiang() : '',
                    wuHou: lunar.getWuHou ? lunar.getWuHou() : '',
                    shuJiu: lunar.getShuJiu ? lunar.getShuJiu() : ''
                },
                fuLu: {
                    fu: lunar.getFu ? lunar.getFu() : '',
                    lu: lunar.getLu ? lunar.getLu() : ''
                },
                shichen: this.getShichenData(lunar, times)
            };
        } catch(e) {
            console.error('[万年历] 获取数据失败:', e);
            throw e;
        }
    },

    getWeekNumber(year, month, day) {
        const d = new Date(year, month - 1, day);
        d.setDate(d.getDate() + 4 - (d.getDay() || 7));
        const yearStart = new Date(d.getFullYear(), 0, 1);
        return Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
    },
    
    zhiData: [
        { zhi: '子', animal: '鼠', wuXing: '水', ziWuLiuZhu: '胆囊' },
        { zhi: '丑', animal: '牛', wuXing: '水', ziWuLiuZhu: '肝脏' },
        { zhi: '寅', animal: '虎', wuXing: '土', ziWuLiuZhu: '肺部' },
        { zhi: '卯', animal: '兔', wuXing: '木', ziWuLiuZhu: '大肠' },
        { zhi: '辰', animal: '龙', wuXing: '木', ziWuLiuZhu: '胃部' },
        { zhi: '巳', animal: '蛇', wuXing: '火', ziWuLiuZhu: '脾脏' },
        { zhi: '午', animal: '马', wuXing: '火', ziWuLiuZhu: '心脏' },
        { zhi: '未', animal: '羊', wuXing: '土', ziWuLiuZhu: '小肠' },
        { zhi: '申', animal: '猴', wuXing: '土', ziWuLiuZhu: '膀胱' },
        { zhi: '酉', animal: '鸡', wuXing: '金', ziWuLiuZhu: '肾脏' },
        { zhi: '戌', animal: '狗', wuXing: '金', ziWuLiuZhu: '膻中' },
        { zhi: '亥', animal: '猪', wuXing: '水', ziWuLiuZhu: '三焦' }
    ],

    getWuXingFromZhi(yearZhi, monthZhi, dayZhi, hourZhi) {
        const getWuXing = (zhi) => {
            const info = this.zhiData.find(d => d.zhi === zhi);
            return info ? info.wuXing : '';
        };
        return {
            year: getWuXing(yearZhi),
            month: getWuXing(monthZhi),
            day: getWuXing(dayZhi),
            hour: getWuXing(hourZhi)
        };
    },
    
    getTimesYiJi(times) {
        const result = [];
        for (let i = 0; i < 12; i++) {
            let yi = [], ji = [];
            try {
                if (times[i]) {
                    if (times[i].getTimeYi) yi = times[i].getTimeYi() || [];
                    if (times[i].getTimeJi) ji = times[i].getTimeJi() || [];
                }
            } catch(e) {}
            result.push({ yi, ji });
        }
        return result;
    },
    
    getShichenData(lunar, times) {
        const currentHour = new Date().getHours();
        const result = [];
        
        for (let i = 0; i < 12; i++) {
            const startHour = (i * 2 + 23) % 24;
            const endHour = (startHour + 2) % 24;
            const isCurrent = startHour < endHour 
                ? currentHour >= startHour && currentHour < endHour
                : currentHour >= startHour || currentHour < endHour;
            
            let ganzhi = '', nineStar = '', naYin = '', yi = [], ji = [];
            try {
                if (times[i]) {
                    ganzhi = times[i].getTimeInGanZhi ? times[i].getTimeInGanZhi() : '';
                    nineStar = times[i].getTimeNineStar ? times[i].getTimeNineStar() : '';
                    naYin = times[i].getTimeNaYin ? times[i].getTimeNaYin() : '';
                    if (times[i].getTimeYi) yi = times[i].getTimeYi() || [];
                    if (times[i].getTimeJi) ji = times[i].getTimeJi() || [];
                }
            } catch(e) {}
            
            const zhiInfo = this.zhiData[i];
            
            result.push({
                name: this.shichenNames[i],
                timeRange: `${String(startHour).padStart(2, '0')}-${String(endHour).padStart(2, '0')}`,
                ganzhi, nineStar, naYin, isCurrent, yi, ji,
                zhiInfo
            });
        }
        return result;
    },
    
    async loadData() {
        const container = document.getElementById('almanac-container');
        if (!container) return;
        
        container.innerHTML = '<div class="almanac-loading"><div class="spinner"></div></div>';
        
        try {
            const today = new Date();
            const data = this.getDateData(today.getFullYear(), today.getMonth() + 1, today.getDate());
            this.currentData = data;
            this.render(data, container);
        } catch(error) {
            this.showError(error.message);
        }
    },
    
    refresh() {
        this.loadData();
    },
    
    showError(msg) {
        const container = document.getElementById('almanac-container');
        if (container) {
            container.innerHTML = `
                <div class="almanac-error">
                    <p>加载失败</p>
                    <button class="retry-btn" onclick="AlmanacModule.refresh()">重试</button>
                </div>
            `;
        }
    },
    
    render(data, container) {
        const { solar, lunar, ganzhi, naYin, wuXing, nineStar, xun, yiJi, shensha, position, chongSha, xiu, jianchu, pengZu, taiWu, fuLu, shichen } = data;

        const weekClass = solar.isWeekend ? ' weekend' : '';
        const leapBadge = lunar.isLeapMonth ? '<span class="leap-badge">闰</span>' : '';
        
        // 合并所有节日
        const allFestivals = [];
        if (solar.festivals?.length) allFestivals.push(...solar.festivals);
        if (solar.otherFestivals?.length) allFestivals.push(...solar.otherFestivals);
        if (lunar.festivals?.length) allFestivals.push(...lunar.festivals);
        
        const huangdiYear = solar.year + 2697;
        const chongDesc = `${lunar.zodiac}日冲${chongSha.dayChong || ''} ${chongSha.daySha || ''}`;
        
        // 时辰吉凶判断
        const shichenLuck = shichen.map((sc) => {
            let luckText = '';
            let luckClass = '';
            if (sc.yi?.length > 0 && sc.ji?.length === 0) {
                luckText = '吉';
                luckClass = 'luck-good';
            } else if (sc.ji?.length > 0 && sc.yi?.length === 0) {
                luckText = '凶';
                luckClass = 'luck-bad';
            } else if (sc.yi?.length >= sc.ji?.length) {
                luckText = '吉';
                luckClass = 'luck-good';
            } else {
                luckText = '凶';
                luckClass = 'luck-bad';
            }
            return { ...sc, luckText, luckClass };
        });
        
        const html = `
<div class="almanac-module">
    <div class="alm-card">
        <!-- 顶部区域：公历日期 + 农历 + 星期 -->
        <div class="alm-header">
            <div class="alm-solar-date">
                <button class="alm-nav-btn" onclick="AlmanacModule.changeDate(-1)">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <span>${solar.year}年${solar.month}月${solar.day}日</span>
                <button class="alm-nav-btn" onclick="AlmanacModule.changeDate(1)">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 6 15 12 9 18"/></svg>
                </button>
            </div>
            <div class="alm-lunar-info">
                <span class="alm-lunar-text">${lunar.monthName}月${lunar.dayName}</span>
                <span class="alm-shengxiao">(属${lunar.zodiac})</span>
                <span class="alm-week">${solar.week}</span>
            </div>
        </div>
        
        <!-- 干支四柱信息 -->
        <div class="alm-ganzhi-row">
            <span class="alm-gz-item"><span class="alm-gz-label">年</span>${ganzhi.year}</span>
            <span class="alm-gz-sep"></span>
            <span class="alm-gz-item"><span class="alm-gz-label">月</span>${ganzhi.month}</span>
            <span class="alm-gz-sep"></span>
            <span class="alm-gz-item"><span class="alm-gz-label">日</span>${ganzhi.day}</span>
            <span class="alm-gz-sep"></span>
            <span class="alm-gz-item"><span class="alm-gz-label">时</span>${ganzhi.hour || '--'}</span>
        </div>
        
        <!-- 宜忌展示 -->
        <div class="alm-yiji-area">
            <div class="alm-yi-box">
                <div class="alm-yi-header">
                    <span class="alm-yi-dot"></span>
                    <span>宜</span>
                </div>
                <div class="alm-yi-content">${yiJi.dayYi.slice(0, 10).join(' ')}</div>
            </div>
            <div class="alm-ji-box">
                <div class="alm-ji-header">
                    <span class="alm-ji-dot"></span>
                    <span>忌</span>
                </div>
                <div class="alm-ji-content">${yiJi.dayJi.slice(0, 6).join(' ')}</div>
            </div>
        </div>
        
        <!-- 吉凶神煞信息（横向网格） -->
        <div class="alm-shensha-grid">
            <div class="alm-ss-item">
                <span class="alm-ss-label">吉神宜趋</span>
                <span class="alm-ss-value">${shensha.good.slice(0, 4).join(' ')}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label danger">凶神宜忌</span>
                <span class="alm-ss-value">${shensha.bad.slice(0, 4).join(' ')}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">彭祖百忌</span>
                <span class="alm-ss-value">${pengZu.gan || ''} ${pengZu.zhi || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label warn">冲煞</span>
                <span class="alm-ss-value">${chongDesc}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">五行</span>
                <span class="alm-ss-value">${naYin.day || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">胎神</span>
                <span class="alm-ss-value">${taiWu.taiShen || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">喜神</span>
                <span class="alm-ss-value">${position.xi || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">财神</span>
                <span class="alm-ss-value">${position.cai || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">福神</span>
                <span class="alm-ss-value">${position.fu || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">月相</span>
                <span class="alm-ss-value">${taiWu.yueXiang || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">值神</span>
                <span class="alm-ss-value">${jianchu.zhiXing || ''}</span>
            </div>
            <div class="alm-ss-item">
                <span class="alm-ss-label">建除</span>
                <span class="alm-ss-value">${jianchu.liuYao || ''}</span>
            </div>
        </div>
        
        <!-- 时辰吉凶横排 -->
        <div class="alm-shichen-row">
            <div class="alm-shichen-title">时辰吉凶</div>
            <div class="alm-shichen-items">
                ${shichenLuck.map(sc => `
                    <div class="alm-sc ${sc.isCurrent ? 'current' : ''}">
                        <span class="alm-sc-gz">${sc.ganzhi}</span>
                        <span class="alm-sc-luck ${sc.luckClass}">${sc.luckText}</span>
                    </div>`).join('')}
            </div>
        </div>
        
        <!-- 详细数据折叠区 -->
        <details class="alm-detail-panel">
            <summary class="alm-detail-summary">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                查看详细数据
            </summary>
            <div class="alm-detail-content">
                <!-- 八字表格 -->
                <div class="alm-bazi-table">
                    <div class="alm-bazi-title">八字信息</div>
                    <div class="alm-grid">
                        <div class="alm-row alm-row-head">
                            <span class="alm-label"></span>
                            <span>年柱</span><span>月柱</span><span>日柱</span><span>时柱</span>
                        </div>
                        <div class="alm-row">
                            <span class="alm-label">天干</span>
                            <span class="alm-value">${ganzhi.yearGan}</span>
                            <span class="alm-value">${ganzhi.monthGan}</span>
                            <span class="alm-value">${ganzhi.dayGan}</span>
                            <span class="alm-value">${ganzhi.hourGan}</span>
                        </div>
                        <div class="alm-row">
                            <span class="alm-label">地支</span>
                            <span class="alm-value">${ganzhi.yearZhi}</span>
                            <span class="alm-value">${ganzhi.monthZhi}</span>
                            <span class="alm-value">${ganzhi.dayZhi}</span>
                            <span class="alm-value">${ganzhi.hourZhi}</span>
                        </div>
                        <div class="alm-row">
                            <span class="alm-label">五行</span>
                            <span class="alm-value small">${wuXing.year || ''}</span>
                            <span class="alm-value small">${wuXing.month || ''}</span>
                            <span class="alm-value small">${wuXing.day || ''}</span>
                            <span class="alm-value small">${wuXing.hour || ''}</span>
                        </div>
                        <div class="alm-row">
                            <span class="alm-label">纳音</span>
                            <span class="alm-value small">${naYin.year || ''}</span>
                            <span class="alm-value small">${naYin.month || ''}</span>
                            <span class="alm-value small">${naYin.day || ''}</span>
                            <span class="alm-value small">${naYin.hour || ''}</span>
                        </div>
                        <div class="alm-row">
                            <span class="alm-label">九星</span>
                            <span class="alm-value small">${nineStar.year || ''}</span>
                            <span class="alm-value small">${nineStar.month || ''}</span>
                            <span class="alm-value small accent">${nineStar.day || ''}</span>
                            <span class="alm-value small">${nineStar.hour || ''}</span>
                        </div>
                        ${ganzhi.baZiShiShenDay ? `
                        <div class="alm-row alm-row-shishen">
                            <span class="alm-label">日主<br>十神</span>
                            <span class="alm-value highlight">${ganzhi.baZiShiShenDay}</span>
                        </div>` : ''}
                    </div>
                </div>
                
                <!-- 旬空信息 -->
                <div class="alm-xun-info">
                    <div class="alm-xun-row">
                        <span class="alm-xun-label">旬</span>
                        <span>${xun.year}</span>
                        <span>${xun.month}</span>
                        <span>${xun.day}</span>
                        <span class="alm-kong">${[xun.yearKong, xun.monthKong, xun.dayKong].filter(v=>v).join('')}空</span>
                    </div>
                </div>
                
                <!-- 二十八星宿 -->
                <div class="alm-xiu-info">
                    <span class="alm-xiu-label">二十八星宿</span>
                    <span class="alm-xiu-value">${xiu.name || ''} ${xiu.luck || ''}</span>
                </div>
                
                <!-- 节气信息 -->
                <div class="alm-jieqi-info">
                    <div class="alm-jieqi-row">
                        <span class="alm-jieqi-label">节气</span>
                        <span>${solar.jieQi || ''}</span>
                        <span>${solar.currentJieQi || ''}</span>
                        <span>${solar.nextJie || ''}</span>
                        <span>${solar.nextQi || ''}</span>
                    </div>
                </div>
                
                <!-- 宜忌完整列表 -->
                <div class="alm-yiji-full">
                    <div class="alm-yi-full">
                        <span class="alm-yi-full-label">宜</span>
                        <span class="alm-yi-full-text">${yiJi.dayYi.join(' ')}</span>
                    </div>
                    <div class="alm-ji-full">
                        <span class="alm-ji-full-label">忌</span>
                        <span class="alm-ji-full-text">${yiJi.dayJi.join(' ')}</span>
                    </div>
                </div>
                
                <!-- 时辰吉凶详表 -->
                <div class="alm-shichen-full">
                    <div class="alm-shichen-full-title">时辰吉凶详表</div>
                    <div class="alm-shichen-full-grid">
                        ${shichen.map(sc => {
                            const zhi = sc.zhiInfo || {};
                            return `
                        <div class="alm-sc-full ${sc.isCurrent ? 'current' : ''}">
                            <span class="alm-sc-name">${sc.name}</span>
                            <span class="alm-sc-gz-full">${sc.ganzhi}</span>
                            <span class="alm-sc-luck-full ${sc.luckClass}">${sc.luckText}</span>
                        </div>`;
                        }).join('')}
                    </div>
                </div>
            </div>
        </details>
        
        <!-- 数据来源 -->
        <div class="alm-source">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            <span>lunar-javascript</span>
        </div>
    </div>
</div>`;
        
        container.innerHTML = html;
    },
    
    toChineseYear(year) {
        const digits = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
        return String(year).split('').map(d => digits[parseInt(d)]).join('');
    },
    
    changeDate(offset) {
        if (!this.currentData) return;
        const { solar } = this.currentData;
        const date = new Date(solar.year, solar.month - 1, solar.day + offset);
        try {
            const data = this.getDateData(date.getFullYear(), date.getMonth() + 1, date.getDate());
            this.currentData = data;
            const container = document.getElementById('almanac-container');
            if (container) this.render(data, container);
        } catch(e) {
            console.error('[万年历] 切换日期失败:', e);
        }
    }
};