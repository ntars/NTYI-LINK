# lunar-javascript

无依赖的支持阳历、阴历、佛历和道历的日历工具库。

## 来源

官网: https://6tail.cn/calendar/

GitHub: https://github.com/6tail/lunar-javascript

## CDN

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/lunar-javascript/1.7.5/lunar.min.js"></script>
<script src="https://cdn.staticfile.org/lunar-javascript/1.7.5/lunar.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lunar-javascript@1.7.7/lunar.js"></script>
```

## NPM

```bash
npm install lunar-javascript
```

## 目录结构

```
libs/lunar-javascript/
├── lunar.js                 # 主库文件
├── README.md                # 本文件
└── docs/
    ├── api-reference.js     # API 参考文档
    ├── quick-start.js       # 快速开始示例
    └── full-api.js          # 完整API文档(所有方法)
```

## 快速开始

```javascript
// 引入库后直接使用
console.log(Lunar.fromDate(new Date()).toFullString());
console.log(Solar.fromYmd(2016, 1, 1).toFullString());
console.log(HolidayUtil.getHoliday(2020, 5, 2) + '');
```

## 主要类

| 类名 | 说明 |
|------|------|
| Solar | 阳历 |
| Lunar | 阴历/农历 |
| Foto | 佛历 |
| Tao | 道历 |
| HolidayUtil | 法定假日工具 |
| NineStar | 九星 |
| LiuYao | 六曜 |

---

## 完整API文档

### 1. Solar (阳历类)

#### 实例化方法

| 方法 | 说明 | 示例 |
|------|------|------|
| `Solar.fromYmd(year, month, day)` | 从年月日创建 | `Solar.fromYmd(2026,5,13)` |
| `Solar.fromYmdHms(year, month, day, hour, min, sec)` | 从完整时间创建 | |
| `Solar.fromDate(date)` | 从Date对象创建 | `Solar.fromDate(new Date())` |
| `Solar.fromJulianDay(jd)` | 从儒略日创建 | |
| `Solar.fromSolar(solar)` | 阳历转换 | |

#### 基础属性

| 方法 | 说明 | 示例返回值 |
|------|------|-----------|
| `getYear()` | 获取年 | 2026 |
| `getMonth()` | 获取月 | 5 |
| `getDay()` | 获取日 | 13 |
| `getHour()` | 获取小时 | 14 |
| `getMinute()` | 获取分钟 | 30 |
| `getSecond()` | 获取秒 | 0 |
| `getWeek()` | 获取星期(0=周日,1=周一...) | 3 |
| `getWeekInChinese()` | 获取中文星期 | 星期三 |
| `getJulianDay()` | 获取儒略日 | 2458960.5 |
| `getDaysInMonth()` | 获取当月天数 | 31 |
| `getDaysOfYear()` | 获取当年天数 | 365 |

#### 转换方法

| 方法 | 说明 |
|------|------|
| `getLunar()` | 转换为阴历 |
| `toFullString()` | 完整字符串: 2026-05-13 14:30:00 星期三 |
| `toString()` | 字符串: 2026-05-13 |
| `toYmd()` | 年月日: 2026-05-13 |
| `toYmdHms()` | 年月日时分秒 |
| `toUtil()` | 转换为JavaScript Date |

#### 节日与星座

| 方法 | 说明 |
|------|------|
| `getFestivals()` | 获取阳历节日数组 |
| `getOtherFestivals()` | 获取其他节日 |
| `getXingzuo()` | 获取星座: 白羊座 |
| `getXingZuo()` | 获取星座(全拼) |

#### 节气

| 方法 | 说明 |
|------|------|
| `getJieQi()` | 获取节气: 小满 |
| `getJieQiTable()` | 获取全年节气表 |
| `getNearJieQi()` | 获取最近的节气 |
| `getCurrentJie()` | 获取最近的节 |
| `getCurrentQi()` | 获取最近的气 |
| `getNextJieQi()` | 获取下一个节气 |
| `getPrevJieQi()` | 获取上一个节气 |

#### 判断

| 方法 | 说明 |
|------|------|
| `isLeapYear()` | 是否闰年 |
| `isWork()` | 是否工作日 |
| `isAfter(solar)` | 是否在指定日期之后 |
| `isBefore(solar)` | 是否在指定日期之前 |

---

### 2. Lunar (阴历类)

#### 实例化方法

| 方法 | 说明 | 示例 |
|------|------|------|
| `Lunar.fromYmd(year, month, day)` | 阴历年月日(闰月用负数) | `Lunar.fromYmd(2026,4,21)` |
| `Lunar.fromYmd(-4, 5, 1)` | 闰月(负数): 闰四月初一 | |
| `Lunar.fromYmdHms(...)` | 带时分秒 | |
| `Lunar.fromDate(date)` | 从Date对象转换 | |
| `Lunar.fromSolar(solar)` | 从阳历转换 | |

#### 基础属性

| 方法 | 说明 | 示例返回值 |
|------|------|-----------|
| `getYear()` | 年 | 2026 |
| `getMonth()` | 月 | 4 |
| `getDay()` | 日 | 21 |
| `getHour()` | 小时 | 14 |
| `isLeapMonth()` | 是否闰月 | false |
| `getLeapMonth()` | 闰几月(0=无闰) | 0 |

#### 中文转换

| 方法 | 说明 | 示例 |
|------|------|------|
| `getYearInChinese()` | 中文年 | 二〇二六 |
| `getMonthInChinese()` | 中文月 | 四 |
| `getDayInChinese()` | 中文日 | 廿一 |
| `getShengxiao()` | 生肖 | 蛇 |

#### 干支 (八字)

| 方法 | 说明 | 示例 |
|------|------|------|
| **年柱** | | |
| `getYearInGanZhi()` | 年柱干支 | 丙午 |
| `getYearGan()` | 年干 | 丙 |
| `getYearZhi()` | 年支 | 午 |
| `getYearGanIndex()` | 年干索引(0-9) | |
| `getYearZhiIndex()` | 年支索引(0-11) | |
| **月柱** | | |
| `getMonthInGanZhi()` | 月柱干支 | 癸巳 |
| `getMonthGan()` | 月干 | 癸 |
| `getMonthZhi()` | 月支 | 巳 |
| **日柱** | | |
| `getDayInGanZhi()` | 日柱干支 | 戊午 |
| `getDayGan()` | 日干 | 戊 |
| `getDayZhi()` | 日支 | 午 |
| **时柱** | | |
| `getTimeInGanZhi()` | 时柱干支 | 戊午 |
| `getTimeGan()` | 时干 | 戊 |
| `getTimeZhi()` | 时支 | 午 |
| **精确干支** | | |
| `getYearInGanZhiExact()` | 精确年柱 | |
| `getMonthInGanZhiExact()` | 精确月柱 | |
| `getDayInGanZhiExact()` | 精确日柱 | |
| **完整八字** | | |
| `getBaZi()` | 八字数组 | `['丙午','癸巳','戊午','戊午']` |

#### 纳音五行

| 方法 | 说明 | 示例 |
|------|------|------|
| `getYearNaYin()` | 年纳音 | 天上火 |
| `getMonthNaYin()` | 月纳音 | 年命纳音 |
| `getDayNaYin()` | 日纳音 | 日主纳音 |
| `getTimeNaYin()` | 时纳音 | |

#### 九星

| 方法 | 说明 |
|------|------|
| `getYearNineStar()` | 年九星 |
| `getMonthNineStar()` | 月九星 |
| `getDayNineStar()` | 日九星 |
| `getTimeNineStar()` | 时九星 |

#### 旬

| 方法 | 说明 |
|------|------|
| `getYearXun()` | 年旬 |
| `getMonthXun()` | 月旬 |
| `getDayXun()` | 日旬 |
| `getYearXunKong()` | 年旬空 |
| `getMonthXunKong()` | 月旬空 |
| `getDayXunKong()` | 日旬空 |

#### 宜忌

| 方法 | 说明 | 返回类型 |
|------|------|----------|
| `getDayYi()` | 日宜 | 数组 |
| `getDayJi()` | 日忌 | 数组 |
| `getTimeYi()` | 时宜 | 数组 |
| `getTimeJi()` | 时忌 | 数组 |

#### 神煞

| 方法 | 说明 | 返回类型 |
|------|------|----------|
| `getDayJiShen()` | 吉神 | 数组 |
| `getDayXiongSha()` | 凶煞 | 数组 |
| `getTimeJiShen()` | 时吉神 | 数组 |
| `getTimeXiongSha()` | 时凶煞 | 数组 |

#### 冲煞

| 方法 | 说明 |
|------|------|
| `getDayChong()` | 日冲 |
| `getDayChongDesc()` | 日冲描述 |
| `getDayChongGan()` | 日冲干 |
| `getDayChongGanTie()` | 日冲干合 |
| `getDayChongShengXiao()` | 日冲生肖 |
| `getDaySha()` | 日煞 |
| `getTimeChong()` | 时冲 |
| `getTimeSha()` | 时煞 |

#### 方位

| 方法 | 说明 |
|------|------|
| `getDayPositionTai()` | 日太岁冲 |
| `getDayPositionCai()` | 日财 |
| `getDayPositionCaiDesc()` | 日财描述 |
| `getDayPositionFu()` | 日福 |
| `getDayPositionXi()` | 日喜 |
| `getDayPositionYangGui()` | 日阳贵 |
| `getDayPositionYinGui()` | 日阴贵 |
| `getDayPositionTaiSui()` | 日太岁 |

#### 其他吉凶

| 方法 | 说明 | 示例 |
|------|------|------|
| `getXiu()` | 星宿 | 亢 |
| `getXiuLuck()` | 星宿吉凶 | 吉 |
| `getZhiXing()` | 建除 | 执 |
| `getLiuYao()` | 六曜 | 友引 |
| `getPengzu()` | 彭祖百忌 | 戊不受田... |
| `getFu()` | 福神 | 喜神 |
| `getLu()` | 禄神 | 财神 |
| `getTaiShen()` | 胎神 | 碓磨门外... |
| `getYueXiang()` | 月相 | 满月 |
| `getWuHou()` | 物候 | 苦菜秀 |
| `getShuJiu()` | 数九 | 九九 |

#### 十神

| 方法 | 说明 |
|------|------|
| `getTianShen()` | 天干十神 |
| `getDayShiShenGan()` | 日干十神 |
| `getDayShiShenZhi()` | 日支十神 |
| `getTimeShiShenGan()` | 时干十神 |
| `getTimeShiShenZhi()` | 时支十神 |

#### 五行

| 方法 | 说明 |
|------|------|
| `getWuXing()` | 五行 |
| `getYearWuXing()` | 年五行 |
| `getMonthWuXing()` | 月五行 |
| `getDayWuXing()` | 日五行 |
| `getTimeWuXing()` | 时五行 |

#### 转换

| 方法 | 说明 |
|------|------|
| `getSolar()` | 转阳历 |
| `getTimes()` | 获取12时辰数组 |
| `getFoto()` | 转佛历 |
| `getTao()` | 转道历 |

---

### 3. 节日相关

| 方法 | 说明 |
|------|------|
| `Festival.fromYmd(year, month, day)` | 从阳历创建 |
| `Festival.fromLunar(month, day)` | 从农历创建 |
| `HolidayUtil.getHoliday(year, month, day)` | 获取指定日期假日 |
| `HolidayUtil.getHolidays(year)` | 获取全年假日 |
| `HolidayUtil.getHolidaysByTarget(year, month)` | 获取指定月份假日 |

---

### 4. 辅助类

#### SolarMonth (阳历月)

```javascript
var month = SolarMonth.fromYm(2026, 5);
month.getWeeks();           // 获取周数组
month.getFirstDay();       // 第一天
```

#### SolarYear (阳历年)

```javascript
var year = SolarYear.fromYear(2026);
year.getMonths();          // 获取月数组
```

#### LunarMonth (阴历月)

```javascript
var month = LunarMonth.fromYm(2026, 4);
month.getDayCount();       // 天数
month.getFirstDay();       // 第一天
```

#### LunarYear (阴历年)

```javascript
var year = LunarYear.fromYear(2026);
year.getMonths();          // 获取月数组
year.getLeapMonth();       // 闰月(0=无)
year.getJieQiTable();      // 节气表
```

#### NineStar (九星)

```javascript
var star = NineStar.fromIndex(5);  // 0-8
star.getName();    // 五黄土
star.getColor();   // 黄
star.getWuXing();  // 土
```

#### LiuYao (六曜)

```javascript
var yao = LiuYao.fromIndex(0);  // 0-5
yao.getName();    // 先胜
yao.getColor();   // 颜色
```

---

### 5. 特殊日期判断

```javascript
// 吉凶日判断
lunar.isDayAnWu();          // 暗乌日
lunar.isDayBaHui();         // 八会日
lunar.isDayBaJie();         // 八节日
lunar.isDayMingWu();        // 明乌日
lunar.isDaySanHui();        // 三会日
lunar.isDaySanYuan();       // 三元日
lunar.isDayTianShe();       // 天社日
lunar.isDayWuLa();          // 五腊日
lunar.isDayYangGong();      // 阳贡日
lunar.isDayZhaiGuanYin();   // 斋戒观音日
lunar.isDayZhaiShuoWang();  // 斋戒十王日
lunar.isDayZhaiSix();       // 斋戒六日
lunar.isDayZhaiTen();       // 斋戒十日

// 其他判断
lunar.isJie();              // 是否节气当天
lunar.isQi();               // 是否中气当天
lunar.isLeap();             // 是否闰月
lunar.isLeapYear();         // 是否闰年
```

---

### 完整使用示例

```javascript
// 示例1: 获取当前日期的完整信息
var today = new Date();
var solar = Solar.fromDate(today);
var lunar = solar.getLunar();

console.log('阳历:', solar.toFullString());
console.log('农历:', lunar.getMonthInChinese() + '月' + lunar.getDayInChinese());
console.log('八字:', lunar.getBaZi().join(' '));
console.log('节气:', lunar.getJieQi());
console.log('宜:', lunar.getDayYi().slice(0, 5));
console.log('忌:', lunar.getDayJi().slice(0, 5));

// 示例2: 查询指定日期
var solar2 = Solar.fromYmd(2026, 5, 13);
var lunar2 = solar2.getLunar();

console.log('年柱:', lunar2.getYearInGanZhi());
console.log('月柱:', lunar2.getMonthInGanZhi());
console.log('日柱:', lunar2.getDayInGanZhi());
console.log('时柱:', lunar2.getTimeInGanZhi());
console.log('纳音:', lunar2.getYearNaYin(), lunar2.getMonthNaYin(), lunar2.getDayNaYin());
console.log('九星:', lunar2.getYearNineStar(), lunar2.getMonthNineStar(), lunar2.getDayNineStar());

// 示例3: 获取八字详细信息
var bazi = lunar2.getBaZi();
var shiShen = lunar2.getBaZiShiShenDayZhi();
var wuXing = lunar2.getBaZiWuXing();
console.log('八字:', bazi.join(' '));
console.log('日干十神:', shiShen);
console.log('五行:', wuXing);
```

---

## 版本

当前版本: 1.7.7
